from django.test import TestCase
from django.test import Client
from django.conf import settings
from auction.models import *
from auction.forms import *
from datetime import *


class User_Form_Test(TestCase):

	def setUp(self):
		u = User.objects.create(username='bidder@email.com', email='bidder@email.com')
		u.set_password('123458777')
		u.save()

	def test_UserForm_valid(self):
		form = UserForm(data={'email': "user@mp.com", 'password': "user123", 'first_name': "user", "last_name":"test"})
		self.assertTrue(form.is_valid())

	def test_UserForm_valid_without_fullname(self):
		form = UserForm(data={'email': "user@mp.com", 'password': "user123"})
		self.assertTrue(form.is_valid())

	def test_UserForm_invalid(self):
		form = UserForm(data={'password': "user123", 'first_name': "user", "last_name":"test"})
		self.assertFalse(form.is_valid())

	def test_UserForm_invalid_less_password_char(self):
		form = UserForm(data={'email': "user@mp.com", 'password': "user"})
		self.assertFalse(form.is_valid())

	def test_existing_user(self):
		form = UserForm(data={'email': "bidder@email.com", 'password': "user123", 'first_name': "user", "last_name":"test"})
		self.assertFalse(form.is_valid())


class Auction_Form_Test(TestCase):

	def setUp(self):
		self.user = User.objects.create_user('newsposter','newsposter@news.com', 'newspass')

	def test_AuctionForm_valid(self):
		expire_date_default = date.today() + timedelta(days = 3)
		form = AuctionForm(data={'title': 'test new auction', 'description': 'test description new auction', 'price_0': '100', 'price_1': 'EUR', 'expire': expire_date_default})
		self.assertTrue(form.is_valid())

	def test_AuctionForm_invalid_expire(self):
		expire_date_default = date.today() + timedelta(days = 1)
		form = AuctionForm(data={'title': 'test new auction', 'description': 'test description new auction', 'price_0': '100', 'price_1': 'EUR', 'expire': expire_date_default})
		self.assertFalse(form.is_valid())

	def test_AuctionForm_invalid_title(self):
		expire_date_default = date.today() + timedelta(days = 3)
		form = AuctionForm(data={'title': '', 'description': 'test description new auction', 'price_0': '100', 'price_1': 'EUR', 'expire': expire_date_default})
		self.assertFalse(form.is_valid())

	def test_AuctionForm_invalid_description(self):
		expire_date_default = date.today() + timedelta(days = 3)
		form = AuctionForm(data={'title': 'test', 'description': '', 'price_0': '100', 'price_1': 'EUR', 'expire': expire_date_default})
		self.assertFalse(form.is_valid())

	def test_AuctionForm_invalid_price(self):
		expire_date_default = date.today() + timedelta(days = 3)
		form = AuctionForm(data={'title': 'test', 'description': 'test description', 'expire': expire_date_default})
		self.assertFalse(form.is_valid())

	def test_AuctionForm_without_deadline_date(self):
		form = AuctionForm(data={'title': 'test new auction', 'description': 'test description new auction', 'price_0': '100', 'price_1': 'EUR'})
		self.assertFalse(form.is_valid())

	def test_status_new_AuctionForm(self):
		expire_date_default = date.today() + timedelta(days = 3)
		form = AuctionForm(data={'title': 'test new auction', 'description': 'test description new auction', 'price_0': '100', 'price_1': 'EUR', 'expire': expire_date_default})
		data = form.save(commit = False)
		data.account = self.user.profile
		data.save()
		self.assertFalse(data.is_active)
		

class Bid_Form_Test(TestCase):

	def setUp(self):
		expire_date = date.today() + timedelta(days = 3)
		self.user = User.objects.create_user('newsposter','newsposter@news.com', 'newspass')
		self.auction = Auction.objects.create(account = self.user.profile, title = 'test', description = 'test description', price = '100', is_active = True, expire = expire_date, status = 1)
		
	def test_valid_BidForm(self):
		form = BidAuction(data={'bidder': self.user.profile, 'bid_price': '200', 'note': 'test'}, auction = self.auction)
		self.assertTrue(form.is_valid())

	def test_BidForm_less_price(self):
		form = BidAuction(data={'bidder': self.user.profile, 'bid_price': '50', 'note': 'test'}, auction = self.auction)
		self.assertFalse(form.is_valid())

	def test_BidForm_anonymous_user(self):
		form = BidAuction(data={'bid_price': '50', 'note': 'test'}, auction = self.auction)
		self.assertFalse(form.is_valid())

	def test_BidForm_without_note(self):
		form = BidAuction(data={'bidder': self.user.profile, 'bid_price': '200'}, auction = self.auction)
		self.assertTrue(form.is_valid())

	def test_BidForm_without_price(self):
		form = BidAuction(data={'bidder': self.user.profile, 'note': 'test'}, auction = self.auction)
		self.assertFalse(form.is_valid())


